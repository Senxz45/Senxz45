const settings = {
  token: '8222194726:AAE3HBm0-_hRiJ_m98anarN5UlifYhLNFng',
  adminId: '7378128077',
  
   // SET PP 
  pp: 'https://files.catbox.moe/kyw8rv.jpg',
urladmin: 'https://t.me/YaanzNotDev',
  pp: 'https://files.catbox.moe/kyw8rv.jpg',
  
    //SERVER 1
  domain: 'https:yanzz.yanz-gntng.biz.id', // domain
  plta: 'ptla_6ppHnakV17GOkH5uQUZbOLQTaHcLskrQZpIRIqsP', // MASUKIN PTLA 
  pltc: 'ptlc_QrJKD2DMSdiVmgGGNf3FRIzUyzQX0S5ee4Ie', // MASUKIN PLTC
  
  //CREATE PANEL
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15'
};

module.exports = settings;