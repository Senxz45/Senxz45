/*
By 𝐒𝐄𝐍𝐙𝐘𝐅𝐋𝐎𝐖𝐄𝐍
*/

const settings = {
  token: '7717490752:AAHAR_nZDHowBTt428K2wAgmRMUMTG5yTaw', //GANTI SAMA TOKEN LU
  adminId: '7964874451', // GANTI SAMA ID LU
  pp: 'https://i.ibb.co/Pv2mmGRX/20250520-134404.jpg',
urladmin: 'http://t.me/cpanelsenz_bot', // GANTI LINK BOT
  pp: 'https://i.ibb.co/Pv2mmGRX/20250520-134404.jpg',
    //SERVER 1
  domain: '', // isi domain lu
  plta: '', //   isi plta yang sesuai
  pltc: '', // isi pltc yang sesuai
  
  //CREATE PANEL
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15'
};

module.exports = settings;