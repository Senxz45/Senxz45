#Script Arisu-MD
*Base By Kyami Silence*
*Pengembang Script kenn Dev*
*Baileys By Kiuur*

#Script ini gratis Dari kenn
#Dilarang Menjual Belikan

#Sumber
#https://whatsapp.com/channel/0029Vb5eutw5fM5epF3U0X20
